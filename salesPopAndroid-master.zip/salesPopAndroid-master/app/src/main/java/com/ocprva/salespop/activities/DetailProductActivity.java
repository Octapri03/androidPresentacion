package com.ocprva.salespop.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Base64;
import android.widget.ImageView;
import android.widget.TextView;

import com.ocprva.salespop.R;
import com.ocprva.salespop.api.pojo.Foto;
import com.ocprva.salespop.api.pojo.FotoServiceInterfaz;
import com.ocprva.salespop.api.pojo.Product;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class DetailProductActivity extends AppCompatActivity {

    TextView nombreDetail, precioDetail, ubicacionDetail, categoriaDetail, fechaDetail, descripcionDetail;
    ImageView imagenDetalle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_product);

        Product producto = (Product) this.getIntent().getSerializableExtra("producto");
        nombreDetail = findViewById(R.id.nombreDetail);
        precioDetail = findViewById(R.id.precioDetail);
        ubicacionDetail = findViewById(R.id.ubicacionDetail);
        categoriaDetail = findViewById(R.id.categoriaDetail);
        fechaDetail = findViewById(R.id.fechaDetail);
        descripcionDetail = findViewById(R.id.descripcionDetail);
        imagenDetalle = findViewById(R.id.imagenDetalle);

        nombreDetail.setText(producto.getName());
        precioDetail.setText(String.valueOf(producto.getPrice()));
        precioDetail.setText(precioDetail.getText() + "€");
        ubicacionDetail.setText(producto.getUbication());
        categoriaDetail.setText(producto.getCategoria().getName());
        fechaDetail.setText(producto.getPublicationDate());
        descripcionDetail.setText(producto.getDescription());

        if (producto.getFoto().size() > 0){
            String base64String = producto.getFoto().get(0).getUrlImagen(); // The Base64 encoded string
            byte[] decodedBytes = Base64.decode(base64String, Base64.DEFAULT);
            Bitmap bitmap = BitmapFactory.decodeByteArray(decodedBytes, 0, decodedBytes.length);
            imagenDetalle.setImageBitmap(bitmap);
        }
        else{
            Retrofit retrofit = new Retrofit.Builder().baseUrl("http://192.168.8.102:8080/api/").addConverterFactory(GsonConverterFactory.create()).build();
            FotoServiceInterfaz fotoService = retrofit.create(FotoServiceInterfaz.class);
            Call<ArrayList<Foto>> callFoto = fotoService.getFotos();

            callFoto.enqueue(new Callback<ArrayList<Foto>>() {
                @Override
                public void onResponse(Call<ArrayList<Foto>> call, Response<ArrayList<Foto>> response) {
                    for (Foto foto: response.body()) {
                        if (foto.getName().equals(producto.getName()+producto.getId())){
                            String base64String = foto.getUrlImagen(); // The Base64 encoded string
                            byte[] decodedBytes = Base64.decode(base64String, Base64.DEFAULT);
                            Bitmap bitmap = BitmapFactory.decodeByteArray(decodedBytes, 0, decodedBytes.length);
                            imagenDetalle.setImageBitmap(bitmap);
                        }
                    }

                }

                @Override
                public void onFailure(Call<ArrayList<Foto>> call, Throwable t) {

                }
            });
        }

    }


}
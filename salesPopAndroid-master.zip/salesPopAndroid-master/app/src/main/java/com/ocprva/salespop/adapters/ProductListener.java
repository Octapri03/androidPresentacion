package com.ocprva.salespop.adapters;


import com.ocprva.salespop.api.pojo.Product;

public interface ProductListener {
    void onProductoSeleccionada(Product p);
}
